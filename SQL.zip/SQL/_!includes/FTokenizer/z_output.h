/*
 * Author: Andrew Lam
 * Project: FTokenizer
 * Purpose: Returns a single token via extraction operator from a file
 * Notes: Using solitude.txt
 */

#ifndef Z_OUTPUT_H
#define Z_OUTPUT_H
/*
Tokens Found: 145012
==========
*/
#endif // Z_OUTPUT_H