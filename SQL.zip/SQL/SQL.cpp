#include "SQL.h"
#include <iostream>
using namespace std;


int main(){
    SQL sql("_!select.txt");
    sql.run();

    system("PAUSE");
    return 0;
}